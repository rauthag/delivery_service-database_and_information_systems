﻿using AuctionSystem;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AuctionSystem;
using AuctionSystem.ORM;
using System.Diagnostics.Tracing;

namespace Forms
{
    public partial class ShipmentDetail : Form
    {
        public static int globalID;

        public ShipmentDetail(int id)
        {
            globalID = id;
            InitializeComponent();
            InitData();
            typeBox.BorderStyle = BorderStyle.None;
            PriceBox.BorderStyle = BorderStyle.None;
            DelPriceBox.BorderStyle = BorderStyle.None;
            weightBox.BorderStyle = BorderStyle.None;
            OrderBox.BorderStyle = BorderStyle.None;
            DeliveryBox.BorderStyle = BorderStyle.None;
            nameBox.BorderStyle = BorderStyle.None;
            phoneBox.BorderStyle = BorderStyle.None;
            addressBox.BorderStyle = BorderStyle.None;

            typeBox.ReadOnly = true;
            PriceBox.ReadOnly = true;
            DelPriceBox.ReadOnly = true;
            weightBox.ReadOnly = true;
            OrderBox.ReadOnly = true;
            DeliveryBox.ReadOnly = true;
            nameBox.ReadOnly = true;
            phoneBox.ReadOnly = true;
            addressBox.ReadOnly = true;

            typeBox.ForeColor = Color.Black;
            PriceBox.ForeColor = Color.Black;
            DelPriceBox.ForeColor = Color.Black;
            weightBox.ForeColor = Color.Black;
            OrderBox.ForeColor = Color.Black;
            DeliveryBox.ForeColor = Color.Black;
            nameBox.ForeColor = Color.Black;
            phoneBox.ForeColor = Color.Black;
            addressBox.ForeColor = Color.Black;
        }

        private void InitData()
        {

            List<Shipment> shipmentDetails = dbProcesor.ShipmentDetails(globalID);

            if (shipmentDetails == null) return;


            foreach (Shipment val in shipmentDetails)
            {
                typeBox.Text = val.Type;
                PriceBox.Text = val.Price.ToString() + "€";
                DelPriceBox.Text = val.DeliveryPrice.ToString() + "€";
                weightBox.Text = val.Weight.ToString() + "kg";
                OrderBox.Text = val.OrderTime.ToString().Remove((val.OrderTime.ToString()).Length-8);
                DeliveryBox.Text = val.DeliveryTime.ToString().Remove((val.DeliveryTime.ToString()).Length - 8);
                Person personDetails = dbProcesor.PersonDetails(val.Person.Id);
                nameBox.Text = personDetails.FullName;
                phoneBox.Text = personDetails.PhoneNumber;
                addressBox.Text = personDetails.Address.Street + ", " + personDetails.Address.City;
            }

            HistoryView.Clear();
            HistoryView.TabIndex = 0;
            HistoryView.View = System.Windows.Forms.View.Details;
            HistoryView.MultiSelect = true;
            HistoryView.GridLines = true;


            ColumnHeader dateAndTime = new ColumnHeader();
            dateAndTime.Text = "Čas zmeny";
            dateAndTime.TextAlign = HorizontalAlignment.Left;
            dateAndTime.Width = HistoryView.Width/2;

            ColumnHeader state = new ColumnHeader();
            state.Text = "Stav";
            state.TextAlign = HorizontalAlignment.Left;
            state.Width = HistoryView.Width / 2;

            this.HistoryView.Columns.Add(dateAndTime);
            this.HistoryView.Columns.Add(state);

            List<Shipment> shipmentHistory = dbProcesor.ShipmentHistory(globalID);
            if (shipmentHistory == null) return;

            foreach(Shipment s in shipmentHistory)
            {
                ListViewItem item = new ListViewItem(s.DeliveryTime.Remove((s.DeliveryTime.ToString()).Length - 8));
                item.SubItems.Add(s.Type);
                HistoryView.Items.Add(item);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void ShipmentDetail_Load(object sender, EventArgs e)
        {

        }

        private void typeOutput_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void DelPriceBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void weightBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
