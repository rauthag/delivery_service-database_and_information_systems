﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AuctionSystem.ORM;
using AuctionSystem;
using System.Runtime.InteropServices;

namespace Forms
{
    public partial class updateUser : Form
    {
 
        private List<User> users;
        private int globalID;
        private string gType;
       
        
        public updateUser()
        {
            InitializeComponent();
            ok.Enabled = false;
            InitComboBox();
        }

        public void InitComboBox()
        {
            typeBox.Items.Add("Zákazník");
            typeBox.Items.Add("Kuriér");
            typeBox.Items.Add("Predajca");
            typeBox.Items.Add("Správca skladu");


            users = dbProcesor.GetUserList();

            if (users == null) return;

            foreach (User user in users)
            {
                usersBox.Items.Add(user.Id + "/" +  user.Person.FullName + "/" + user.Login);
            }
        }


        private void usersBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tmp = usersBox.Text;
            string[] splited = tmp.Split('/');
            Int32.TryParse(splited[0], out globalID);

            if(usersBox.SelectedItem == null || typeBox.SelectedItem == null)
            {
                ok.Enabled = false;
            }
            else
            {
                ok.Enabled = true;
            }
        }


        private void typeBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            String tmp = typeBox.Text;
            if (tmp.Equals("Zákazník"))
            {
                gType = "customer";
            }
            if (tmp.Equals(" Kuriér"))
            {
                gType = "courier";
            }
            if (tmp.Equals("Predajca"))
            {
                gType = "seller";
            }
            if (tmp.Equals("Správca skladu"))
            {
                gType = "storage manager";
            }


            if (usersBox.SelectedItem == null || typeBox.SelectedItem == null)
            {
                ok.Enabled = false;
            }
            else
            {
                ok.Enabled = true;
            }
        }

        private void ok_Click(object sender, EventArgs e)
        {
            string type = typeBox.Text;
            int id = globalID;

            dbProcesor.UpdateUser(id, type);
            MessageBox.Show("Užívateľ bol aktualizovaný");
            Close();
            
        }

        private void updateUser_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void loginChangeBox_TextChanged(object sender, EventArgs e)
        {
            if (usersBox.SelectedItem == null || typeBox.SelectedItem == null)
            {
                ok.Enabled = false;
            }
            else
            {
                ok.Enabled = true;
            }
        }
    }
}
